document.write('		 <div class="footerMenu">	\n');
document.write('			<div class="footerMenuList">	\n');
document.write('				<ul>	\n');
document.write('				<li class="first"><a href="http://www.ahnlab.com" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_logo.gif" alt="AhnLab" /></a></li>	\n');
document.write('				<li><a href="http://company.ahnlab.com/company/site/main/comIntroMain.do" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_menu_01.gif" alt="회사소개" /></a></li>	\n');
document.write('				<li><a href="http://company.ahnlab.com/company/site/ir/present_stock_price.jsp" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_menu_02.gif" alt="투자정보" /></a></li>	\n');
document.write('				<li><a href="http://company.ahnlab.com/company/site/recruit/comRecruitMain/comRecruitMainList.do" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_menu_03.gif" alt="채용정보" /></a></li>	\n');
document.write('				<li><a href="http://www.ahnlab.com/kr/site/etc/policy.do" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_menu_04.gif" alt="개인정보취급방침" /></a></li>	\n');
document.write('				<li><a href="http://www.ahnlab.com/kr/site/etc/agreement.do" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_menu_05.gif" alt="이용약관" /></a></li>	\n');
document.write('				<li class="last"><a href="http://www.ahnlab.com/kr/site/etc/contactUs.do" target="_blank"><img src="https://image.ahnlab.com/v365/201408/common/ft_menu_06.gif" alt="Contact Us" /></a></li>	\n');
document.write('				</ul>	\n');
document.write('				<p class="footerTxt"><img src="https://image.ahnlab.com/v365/201408/common/ft_address.gif" alt="(우) 13493 경기도 성남시 분당구 판교역로 220 대표이사 : 권치중 사업자등록번호 : 214-81-83536 통신판매신고번호 : 2012-경기성남-1189 대표전화 : 031-722-8000 Fax : 031-722-8901 구매문의 : 1588-3096 기업고객 기술지원 : 1577-9880" /></p>	\n');
document.write('			</div>	\n');
document.write('		</div>	\n');

document.write('<script language="javascript" src="https://image.ahnlab.com/common/js/makePCookie.js" type="text/javascript"></script>\n');
